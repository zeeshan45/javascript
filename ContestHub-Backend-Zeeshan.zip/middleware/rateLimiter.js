const rateLimit = require('express-rate-limit');

// General API rate limiter
exports.apiLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
  max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // 100 requests per window
  message: {
    error: 'Too many requests from this IP, please try again later'
  },
  standardHeaders: true,
  legacyHeaders: false,
});

// Strict rate limiter for authentication endpoints
exports.authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // 5 requests per window
  message: {
    error: 'Too many authentication attempts, please try again later'
  },
  skipSuccessfulRequests: true,
});

// Rate limiter for contest participation
exports.participationLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10, // 10 contest participations per hour
  message: {
    error: 'Too many contest participations, please try again later'
  },
});

// Rate limiter for submission
exports.submissionLimiter = rateLimit({
  windowMs: 60 * 1000, // 1 minute
  max: 3, // 3 submissions per minute
  message: {
    error: 'Too many submissions, please try again later'
  },
});

