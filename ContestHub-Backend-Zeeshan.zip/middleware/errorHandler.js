const { NODE_ENV } = require('../config/config');

const devErrors = (res, error) => {
  return res.status(error.statusCode).json({
    success: false,
    message: error.statusCode === 500 ? 'Internal Server Error' : error.message,
    stackTrace: error.stack,
  });
};

const prodErrors = (res, error) => {
  return res.status(error.statusCode).json({
    success: false,
    message: error.statusCode === 500 ? 'Internal Server Error' : error.message,
  });
};

module.exports = (error, req, res, next) => {
  console.error(error.message);

  error.statusCode = error.statusCode || 500;
  error.status = error.status || 'Error';

  // Handle Mongoose errors
  if (error.name === 'CastError') {
    error.statusCode = 404;
    error.message = 'Resource not found';
  }

  if (error.code === 11000) {
    const field = Object.keys(error.keyValue || {})[0];
    error.statusCode = 400;
    error.message = `${field || 'Field'} already exists`;
  }

  if (error.name === 'ValidationError') {
    error.statusCode = 400;
    error.message = Object.values(error.errors || {}).map(val => val.message).join(', ');
  }

  if (error.name === 'JsonWebTokenError') {
    error.statusCode = 401;
    error.message = 'Invalid token';
  }

  if (error.name === 'TokenExpiredError') {
    error.statusCode = 401;
    error.message = 'Token expired';
  }

  if (NODE_ENV === 'production') {
    return prodErrors(res, error);
  }

  return devErrors(res, error);
};