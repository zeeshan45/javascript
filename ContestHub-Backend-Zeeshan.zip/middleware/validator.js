const { body, validationResult } = require('express-validator');

// Validation result handler
exports.validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      errors: errors.array()
    });
  }
  next();
};

// User registration validation
exports.validateRegister = [
  body('name')
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Name must be between 3 and 30 characters'),
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .isLength({ min: 8 })
    .withMessage('Password must be at least 8 characters long'),
];

// User login validation
exports.validateLogin = [
  body('email')
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email'),
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
];

// Contest validation
exports.validateContest = [
  body('name')
    .trim()
    .notEmpty()
    .withMessage('Contest name is required'),
  body('description')
    .trim()
    .notEmpty()
    .withMessage('Contest description is required'),
  body('accessLevel')
    .isIn(['normal', 'vip'])
    .withMessage('Access level must be either normal or vip'),
  body('startTime')
    .isISO8601()
    .withMessage('Start time must be a valid ISO 8601 date'),
  body('endTime')
    .isISO8601()
    .withMessage('End time must be a valid ISO 8601 date'),
  body('prize')
    .trim()
    .notEmpty()
    .withMessage('Prize information is required'),
];

// Question validation
exports.validateQuestion = [
  body('contestId')
    .isMongoId()
    .withMessage('Valid contest ID is required'),
  body('questionText')
    .trim()
    .notEmpty()
    .withMessage('Question text is required'),
  body('questionType')
    .isIn(['single-select', 'multi-select', 'true-false'])
    .withMessage('Question type must be single-select, multi-select, or true-false'),
  body('options')
    .isArray({ min: 2 })
    .withMessage('At least 2 options are required'),
  body('options.*.text')
    .trim()
    .notEmpty()
    .withMessage('Option text is required'),
  body('points')
    .optional()
    .isInt({ min: 1 })
    .withMessage('Points must be a positive integer'),
];

// Answer validation
exports.validateAnswers = [
  body('answers')
    .isArray()
    .withMessage('Answers must be an array'),
  body('answers.*.questionId')
    .isMongoId()
    .withMessage('Valid question ID is required'),
  body('answers.*.selectedOptions')
    .isArray()
    .withMessage('Selected options must be an array'),
];

