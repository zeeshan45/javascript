const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Authentication middleware
exports.authenticate = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      // Allow guest access (no token)
      req.user = { role: 'guest', id: null };
      return next();
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_super_secret_jwt_key_change_this_in_production');
    const user = await User.findById(decoded.id).select('-password');
    
    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token' });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    res.status(500).json({ error: 'Authentication failed' });
  }
};

// Require authentication (no guest access)
exports.requireAuth = async (req, res, next) => {
  try {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_super_secret_jwt_key_change_this_in_production');
    const user = await User.findById(decoded.id).select('-password');
    
    if (!user) {
      return res.status(401).json({ error: 'User not found' });
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ error: 'Invalid token' });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'Token expired' });
    }
    res.status(500).json({ error: 'Authentication failed' });
  }
};

// Role-based access control
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !req.user.role) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    if (roles.includes(req.user.role)) {
      return next();
    }

    res.status(403).json({ error: 'Access denied. Insufficient permissions' });
  };
};

// Check if user can access contest
exports.canAccessContest = async (req, res, next) => {
  try {
    const Contest = require('../models/Contest');
    const contest = await Contest.findById(req.params.id);
    
    if (!contest) {
      return res.status(404).json({ error: 'Contest not found' });
    }

    const userRole = req.user?.role || 'guest';

    // Admin and VIP can access all contests
    if (userRole === 'admin' || userRole === 'vip') {
      return next();
    }

    // Normal users can only access normal contests
    if (userRole === 'normal' && contest.accessLevel === 'normal') {
      return next();
    }

    // Guests can only view (GET requests)
    if (userRole === 'guest' && req.method === 'GET') {
      return next();
    }

    // Guests cannot participate
    if (userRole === 'guest') {
      return res.status(403).json({ error: 'Please sign up and login to participate in contests' });
    }

    // VIP contest access denied for normal users
    if (contest.accessLevel === 'vip') {
      return res.status(403).json({ error: 'VIP contests are only accessible to VIP users' });
    }

    next();
  } catch (error) {
    res.status(500).json({ error: 'Error checking contest access' });
  }
};

