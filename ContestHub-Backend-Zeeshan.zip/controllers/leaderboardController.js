const Leaderboard = require('../models/Leaderboard');
const Contest = require('../models/Contest');
const Participation = require('../models/Participation');

exports.getLeaderboard = async (req, res, next) => {
  try {
    const { contestId } = req.params;
    const { limit = 100, offset = 0 } = req.query;

    // Check if contest exists
    const contest = await Contest.findById(contestId);
    if (!contest) {
      return res.status(404).json({
        success: false,
        error: 'Contest not found'
      });
    }

    // Get leaderboard
    let leaderboard = await Leaderboard.findOne({ contestId });

    // If leaderboard doesn't exist, create it from participations
    if (!leaderboard) {
      const participations = await Participation.find({
        contestId,
        status: 'completed'
      })
        .populate('userId', 'name')
        .sort({ totalScore: -1, submittedAt: 1 })
        .limit(parseInt(limit))
        .skip(parseInt(offset));

      const rankings = participations.map((participation, index) => ({
        userId: participation.userId._id,
        name: participation.userId.name,
        score: participation.totalScore,
        rank: index + 1,
        submittedAt: participation.submittedAt
      }));

      leaderboard = await Leaderboard.create({
        contestId,
        rankings,
        lastUpdated: new Date()
      });
    }

    // Apply pagination
    const paginatedRankings = leaderboard.rankings
      .slice(parseInt(offset), parseInt(offset) + parseInt(limit));

    res.json({
      success: true,
      data: {
        contestId: leaderboard.contestId,
        contestName: contest.name,
        totalParticipants: leaderboard.rankings.length,
        rankings: paginatedRankings,
        lastUpdated: leaderboard.lastUpdated
      }
    });
  } catch (error) {
    next(error);
  }
};

exports.getUserRank = async (req, res, next) => {
  try {
    const { contestId } = req.params;
    const userId = req.user.id;

    const participation = await Participation.findOne({
      userId,
      contestId,
      status: 'completed'
    });

    if (!participation) {
      return res.status(404).json({
        success: false,
        error: 'You have not completed this contest'
      });
    }

    const leaderboard = await Leaderboard.findOne({ contestId });

    if (!leaderboard) {
      return res.status(404).json({
        success: false,
        error: 'Leaderboard not found'
      });
    }

    const userRanking = leaderboard.rankings.find(
      ranking => ranking.userId.toString() === userId
    );

    if (!userRanking) {
      return res.status(404).json({
        success: false,
        error: 'Ranking not found'
      });
    }

    res.json({
      success: true,
      data: {
        rank: userRanking.rank,
        score: userRanking.score,
        totalParticipants: leaderboard.rankings.length
      }
    });
  } catch (error) {
    next(error);
  }
};

