const Participation = require('../models/Participation');
const Contest = require('../models/Contest');
const Question = require('../models/Question');
const User = require('../models/User');
const Leaderboard = require('../models/Leaderboard');

exports.startContest = async (req, res, next) => {
  try {
    const { contestId } = req.params;
    const userId = req.user.id;

    // Check if contest exists
    const contest = await Contest.findById(contestId);
    if (!contest) {
      return res.status(404).json({
        success: false,
        error: 'Contest not found'
      });
    }

    // Check access
    const userRole = req.user.role;
    if (userRole === 'normal' && contest.accessLevel === 'vip') {
      return res.status(403).json({
        success: false,
        error: 'VIP contests are only accessible to VIP users'
      });
    }

    // Check if contest is active
    const now = new Date();
    if (now < contest.startTime || now > contest.endTime) {
      return res.status(400).json({
        success: false,
        error: 'Contest is not currently active'
      });
    }

    // Check if user already started this contest
    let participation = await Participation.findOne({ userId, contestId });

    if (participation && participation.status === 'completed') {
      return res.status(400).json({
        success: false,
        error: 'You have already completed this contest'
      });
    }

    if (!participation) {
      // Create new participation
      participation = await Participation.create({
        userId,
        contestId,
        status: 'in-progress'
      });

      // Increment contest participants
      contest.currentParticipants += 1;
      await contest.save();
    }

    // Get questions without correct answers
    const questions = await Question.find({ contestId })
      .select('-options.isCorrect')
      .sort({ order: 1 });

    res.json({
      success: true,
      data: {
        participation: {
          id: participation._id,
          contestId: participation.contestId,
          status: participation.status,
          startedAt: participation.startedAt
        },
        questions
      }
    });
  } catch (error) {
    next(error);
  }
};

exports.submitAnswers = async (req, res, next) => {
  try {
    const { participationId } = req.params;
    const { answers } = req.body;
    const userId = req.user.id;

    // Get participation
    const participation = await Participation.findById(participationId)
      .populate('contestId');

    if (!participation) {
      return res.status(404).json({
        success: false,
        error: 'Participation not found'
      });
    }

    // Verify user owns this participation
    if (participation.userId.toString() !== userId) {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to submit this participation'
      });
    }

    // Check if already submitted
    if (participation.status === 'completed') {
      return res.status(400).json({
        success: false,
        error: 'Contest already submitted'
      });
    }

    // Check if contest is still active
    const contest = participation.contestId;
    const now = new Date();
    if (now > contest.endTime) {
      return res.status(400).json({
        success: false,
        error: 'Contest has ended'
      });
    }

    // Get all questions with correct answers
    const questions = await Question.find({ contestId: contest._id });

    let totalScore = 0;
    const answerResults = [];

    // Evaluate each answer
    for (const userAnswer of answers) {
      const question = questions.find(q => q._id.toString() === userAnswer.questionId);
      
      if (!question) {
        continue; // Skip invalid question IDs
      }

      let isCorrect = false;
      const correctOptionIndices = question.options
        .map((opt, index) => opt.isCorrect ? index : -1)
        .filter(index => index !== -1);

      // Check if answer is correct based on question type
      if (question.questionType === 'single-select') {
        if (userAnswer.selectedOptions.length === 1) {
          isCorrect = correctOptionIndices.includes(userAnswer.selectedOptions[0]);
        }
      } else if (question.questionType === 'multi-select') {
        if (userAnswer.selectedOptions.length === correctOptionIndices.length) {
          isCorrect = userAnswer.selectedOptions.every(opt => 
            correctOptionIndices.includes(opt)
          ) && correctOptionIndices.every(opt => 
            userAnswer.selectedOptions.includes(opt)
          );
        }
      } else if (question.questionType === 'true-false') {
        if (userAnswer.selectedOptions.length === 1) {
          isCorrect = correctOptionIndices.includes(userAnswer.selectedOptions[0]);
        }
      }

      const pointsEarned = isCorrect ? question.points : 0;
      totalScore += pointsEarned;

      answerResults.push({
        questionId: question._id,
        selectedOptions: userAnswer.selectedOptions,
        isCorrect,
        pointsEarned
      });
    }

    // Update participation
    participation.answers = answerResults;
    participation.totalScore = totalScore;
    participation.status = 'completed';
    participation.submittedAt = new Date();

    await participation.save();

    // Update leaderboard after submission
    // Note: Prizes are awarded when contest ends via admin endpoint (/api/contests/:id/finalize-prizes)
    // This ensures the final winner gets the prize after all submissions
    await updateLeaderboard(contest._id);

    res.json({
      success: true,
      data: {
        participation: {
          id: participation._id,
          totalScore,
          status: participation.status,
          submittedAt: participation.submittedAt,
          prizeWon: participation.prizeWon
        },
        answers: answerResults
      }
    });
  } catch (error) {
    next(error);
  }
};

// Helper function to update leaderboard
const updateLeaderboard = async (contestId) => {
  try {
    const participations = await Participation.find({
      contestId,
      status: 'completed'
    })
      .populate('userId', 'name')
      .sort({ totalScore: -1, submittedAt: 1 }); // Sort by score desc, then by submission time asc

    const rankings = participations.map((participation, index) => ({
      userId: participation.userId._id,
      name: participation.userId.name,
      score: participation.totalScore,
      rank: index + 1,
      submittedAt: participation.submittedAt
    }));

    // Update rank in participation
    for (let i = 0; i < participations.length; i++) {
      participations[i].rank = i + 1;
      await participations[i].save();
    }

    // Update or create leaderboard
    await Leaderboard.findOneAndUpdate(
      { contestId },
      {
        contestId,
        rankings,
        lastUpdated: new Date()
      },
      { upsert: true, new: true }
    );
  } catch (error) {
    console.error('Error updating leaderboard:', error);
  }
};

// Helper function to award prize to contest winner
exports.awardPrize = async (contestId) => {
  try {
    const contest = await Contest.findById(contestId);
    if (!contest) return;

    const leaderboard = await Leaderboard.findOne({ contestId });
    if (!leaderboard || leaderboard.rankings.length === 0) return;

    // Get the top-ranked user(s) - handle ties by awarding to first submitter
    const topRank = leaderboard.rankings[0];
    const topScore = topRank.score;

    // Check if prize has already been awarded
    const topParticipation = await Participation.findOne({
      contestId,
      userId: topRank.userId,
      status: 'completed'
    });

    if (topParticipation && !topParticipation.prizeWon) {
      // Award prize to winner
      const user = await User.findById(topRank.userId);
      if (user) {
        // Check if user already has this prize (to avoid duplicates)
        const hasPrize = user.prizesWon.some(
          prize => prize.contestId.toString() === contestId.toString()
        );

        if (!hasPrize) {
          user.prizesWon.push({
            contestId: contest._id,
            contestName: contest.name,
            prize: contest.prize,
            wonAt: new Date()
          });
          await user.save();

          topParticipation.prizeWon = contest.prize;
          await topParticipation.save();
        }
      }
    }
  } catch (error) {
    console.error('Error awarding prize:', error);
  }
};

exports.getParticipation = async (req, res, next) => {
  try {
    const { participationId } = req.params;
    const userId = req.user.id;

    const participation = await Participation.findById(participationId)
      .populate('contestId', 'name description prize')
      .populate('answers.questionId');

    if (!participation) {
      return res.status(404).json({
        success: false,
        error: 'Participation not found'
      });
    }

    // Verify user owns this participation or is admin
    if (participation.userId.toString() !== userId && req.user.role !== 'admin') {
      return res.status(403).json({
        success: false,
        error: 'Not authorized to view this participation'
      });
    }

    res.json({
      success: true,
      data: participation
    });
  } catch (error) {
    next(error);
  }
};
