const Participation = require('../models/Participation');
const User = require('../models/User');
const Contest = require('../models/Contest');

exports.getContestHistory = async (req, res, next) => {
  try {
    const userId = req.user.id;
    const { status } = req.query;

    let query = { userId };
    if (status) {
      query.status = status;
    }

    const participations = await Participation.find(query)
      .populate('contestId', 'name description prize startTime endTime')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      count: participations.length,
      data: participations
    });
  } catch (error) {
    next(error);
  }
};

exports.getInProgressContests = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const participations = await Participation.find({
      userId,
      status: 'in-progress'
    })
      .populate('contestId', 'name description prize startTime endTime')
      .sort({ startedAt: -1 });

    // Filter out contests that have ended
    const activeParticipations = participations.filter(participation => {
      const now = new Date();
      return now <= participation.contestId.endTime;
    });

    res.json({
      success: true,
      count: activeParticipations.length,
      data: activeParticipations
    });
  } catch (error) {
    next(error);
  }
};

exports.getPrizes = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const user = await User.findById(userId).select('prizesWon');

    if (!user) {
      return res.status(404).json({
        success: false,
        error: 'User not found'
      });
    }

    res.json({
      success: true,
      count: user.prizesWon.length,
      data: user.prizesWon
    });
  } catch (error) {
    next(error);
  }
};

exports.getCompletedContests = async (req, res, next) => {
  try {
    const userId = req.user.id;

    const participations = await Participation.find({
      userId,
      status: 'completed'
    })
      .populate('contestId', 'name description prize startTime endTime')
      .sort({ submittedAt: -1 });

    res.json({
      success: true,
      count: participations.length,
      data: participations.map(participation => ({
        id: participation._id,
        contest: participation.contestId,
        totalScore: participation.totalScore,
        rank: participation.rank,
        prizeWon: participation.prizeWon,
        submittedAt: participation.submittedAt
      }))
    });
  } catch (error) {
    next(error);
  }
};

