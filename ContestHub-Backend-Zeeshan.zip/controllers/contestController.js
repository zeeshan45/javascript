const Contest = require('../models/Contest');
const Question = require('../models/Question');

exports.getContests = async (req, res, next) => {
  try {
    const userRole = req.user?.role || 'guest';
    const { status, accessLevel } = req.query;

    // Build query based on user role
    let query = {};
    
    // Normal users can only see normal contests
    if (userRole === 'normal') {
      query.accessLevel = 'normal';
    }
    // Guests can only see normal contests
    else if (userRole === 'guest') {
      query.accessLevel = 'normal';
    }
    // Admin and VIP can see all contests
    // (no filter needed)

    // Apply status filter if provided
    if (status) {
      query.status = status;
    }

    // Apply accessLevel filter if provided (only for admin/vip)
    if (accessLevel && (userRole === 'admin' || userRole === 'vip')) {
      query.accessLevel = accessLevel;
    }

    const contests = await Contest.find(query)
      .populate('questions', 'questionText questionType points')
      .sort({ startTime: -1 });

    // Update contest status based on current time
    contests.forEach(contest => {
      contest.updateStatus();
    });

    res.json({
      success: true,
      count: contests.length,
      data: contests
    });
  } catch (error) {
    next(error);
  }
};

exports.getContest = async (req, res, next) => {
  try {
    const contest = await Contest.findById(req.params.id)
      .populate('questions', 'questionText questionType options points order');

    if (!contest) {
      return res.status(404).json({
        success: false,
        error: 'Contest not found'
      });
    }

    // Update status
    contest.updateStatus();

    const userRole = req.user?.role || 'guest';

    // Check access for guests and normal users
    if (userRole === 'guest' || userRole === 'normal') {
      if (contest.accessLevel === 'vip') {
        return res.status(403).json({
          success: false,
          error: 'VIP contests are only accessible to VIP users'
        });
      }
    }

    res.json({
      success: true,
      data: contest
    });
  } catch (error) {
    next(error);
  }
};

exports.createContest = async (req, res, next) => {
  try {
    // Validate end time is after start time
    if (new Date(req.body.endTime) <= new Date(req.body.startTime)) {
      return res.status(400).json({
        success: false,
        error: 'End time must be after start time'
      });
    }

    const contest = await Contest.create(req.body);

    res.status(201).json({
      success: true,
      data: contest
    });
  } catch (error) {
    next(error);
  }
};

exports.updateContest = async (req, res, next) => {
  try {
    let contest = await Contest.findById(req.params.id);

    if (!contest) {
      return res.status(404).json({
        success: false,
        error: 'Contest not found'
      });
    }

    // Validate end time if both are being updated
    if (req.body.startTime && req.body.endTime) {
      if (new Date(req.body.endTime) <= new Date(req.body.startTime)) {
        return res.status(400).json({
          success: false,
          error: 'End time must be after start time'
        });
      }
    }

    contest = await Contest.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    });

    res.json({
      success: true,
      data: contest
    });
  } catch (error) {
    next(error);
  }
};

exports.deleteContest = async (req, res, next) => {
  try {
    const contest = await Contest.findById(req.params.id);

    if (!contest) {
      return res.status(404).json({
        success: false,
        error: 'Contest not found'
      });
    }

    // Delete associated questions
    await Question.deleteMany({ contestId: contest._id });

    await contest.deleteOne();

    res.json({
      success: true,
      data: {}
    });
  } catch (error) {
    next(error);
  }
};

exports.getContestQuestions = async (req, res, next) => {
  try {
    const contest = await Contest.findById(req.params.id);

    if (!contest) {
      return res.status(404).json({
        success: false,
        error: 'Contest not found'
      });
    }

    const userRole = req.user?.role || 'guest';

    // Check access
    if (userRole === 'guest') {
      return res.status(403).json({
        success: false,
        error: 'Please sign up and login to view contest questions'
      });
    }

    if (userRole === 'normal' && contest.accessLevel === 'vip') {
      return res.status(403).json({
        success: false,
        error: 'VIP contests are only accessible to VIP users'
      });
    }

    // Don't send correct answers
    const questions = await Question.find({ contestId: contest._id })
      .select('-options.isCorrect')
      .sort({ order: 1 });

    res.json({
      success: true,
      count: questions.length,
      data: questions
    });
  } catch (error) {
    next(error);
  }
};

exports.finalizePrizes = async (req, res, next) => {
  try {
    const contest = await Contest.findById(req.params.id);

    if (!contest) {
      return res.status(404).json({
        success: false,
        error: 'Contest not found'
      });
    }

    // Check if contest has ended
    const now = new Date();
    if (now <= contest.endTime) {
      return res.status(400).json({
        success: false,
        error: 'Contest has not ended yet'
      });
    }

    // Update leaderboard first
    const Participation = require('../models/Participation');
    const Leaderboard = require('../models/Leaderboard');
    
    const participations = await Participation.find({
      contestId: contest._id,
      status: 'completed'
    })
      .populate('userId', 'name')
      .sort({ totalScore: -1, submittedAt: 1 });

    if (participations.length === 0) {
      return res.json({
        success: true,
        message: 'No participants to award prizes'
      });
    }

    // Update rankings
    for (let i = 0; i < participations.length; i++) {
      participations[i].rank = i + 1;
      await participations[i].save();
    }

    // Update leaderboard
    const rankings = participations.map((participation, index) => ({
      userId: participation.userId._id,
      name: participation.userId.name,
      score: participation.totalScore,
      rank: index + 1,
      submittedAt: participation.submittedAt
    }));

    await Leaderboard.findOneAndUpdate(
      { contestId: contest._id },
      {
        contestId: contest._id,
        rankings,
        lastUpdated: new Date()
      },
      { upsert: true, new: true }
    );

    // Award prize using the helper function
    const { awardPrize } = require('./participationController');
    await awardPrize(contest._id);

    res.json({
      success: true,
      message: 'Prizes finalized for the contest'
    });
  } catch (error) {
    next(error);
  }
};
