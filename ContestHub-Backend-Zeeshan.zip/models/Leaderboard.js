const mongoose = require('mongoose');

const leaderboardSchema = new mongoose.Schema({
  contestId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contest',
    required: [true, 'Contest ID is required'],
    unique: true
  },
  rankings: [{
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true
    },
    name: {
      type: String,
      required: true
    },
    score: {
      type: Number,
      default: 0
    },
    rank: {
      type: Number,
      required: true
    },
    submittedAt: {
      type: Date,
      default: Date.now
    }
  }],
  lastUpdated: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for efficient queries
leaderboardSchema.index({ contestId: 1 });
leaderboardSchema.index({ 'rankings.userId': 1 });

module.exports = mongoose.model('Leaderboard', leaderboardSchema);

