const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  contestId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contest',
    required: [true, 'Contest ID is required']
  },
  questionText: {
    type: String,
    required: [true, 'Question text is required']
  },
  questionType: {
    type: String,
    enum: ['single-select', 'multi-select', 'true-false'],
    required: [true, 'Question type is required']
  },
  options: [{
    text: {
      type: String,
      required: true
    },
    isCorrect: {
      type: Boolean,
      default: false
    }
  }],
  points: {
    type: Number,
    default: 1,
    min: 1
  },
  order: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Validation for question types
questionSchema.pre('validate', function(next) {
  if (this.questionType === 'true-false' && this.options.length !== 2) {
    return next(new Error('True/False questions must have exactly 2 options'));
  }
  
  if (this.questionType === 'single-select') {
    const correctAnswers = this.options.filter(opt => opt.isCorrect).length;
    if (correctAnswers !== 1) {
      return next(new Error('Single-select questions must have exactly one correct answer'));
    }
  }
  
  if (this.questionType === 'multi-select') {
    const correctAnswers = this.options.filter(opt => opt.isCorrect).length;
    if (correctAnswers < 1) {
      return next(new Error('Multi-select questions must have at least one correct answer'));
    }
  }
  
  next();
});

// Index for efficient queries
questionSchema.index({ contestId: 1, order: 1 });

module.exports = mongoose.model('Question', questionSchema);

