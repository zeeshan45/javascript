const mongoose = require('mongoose');

const contestSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Contest name is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Contest description is required']
  },
  accessLevel: {
    type: String,
    enum: ['normal', 'vip'],
    required: [true, 'Access level is required'],
    default: 'normal'
  },
  startTime: {
    type: Date,
    required: [true, 'Start time is required']
  },
  endTime: {
    type: Date,
    required: [true, 'End time is required'],
    validate: {
      validator: function(value) {
        return value > this.startTime;
      },
      message: 'End time must be after start time'
    }
  },
  prize: {
    type: String,
    required: [true, 'Prize information is required']
  },
  prizeDetails: {
    type: String,
    default: ''
  },
  questions: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Question'
  }],
  status: {
    type: String,
    enum: ['upcoming', 'active', 'ended'],
    default: 'upcoming'
  },
  maxParticipants: {
    type: Number,
    default: null
  },
  currentParticipants: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

// Index for efficient queries
contestSchema.index({ startTime: 1, endTime: 1 });
contestSchema.index({ accessLevel: 1, status: 1 });

// Virtual to check if contest is active
contestSchema.virtual('isActive').get(function() {
  const now = new Date();
  return now >= this.startTime && now <= this.endTime;
});

// Method to update status based on time
contestSchema.methods.updateStatus = function() {
  const now = new Date();
  if (now < this.startTime) {
    this.status = 'upcoming';
  } else if (now >= this.startTime && now <= this.endTime) {
    this.status = 'active';
  } else {
    this.status = 'ended';
  }
  return this.status;
};

module.exports = mongoose.model('Contest', contestSchema);

