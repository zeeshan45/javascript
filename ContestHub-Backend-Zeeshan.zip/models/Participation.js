const mongoose = require('mongoose');

const participationSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: [true, 'User ID is required']
  },
  contestId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Contest',
    required: [true, 'Contest ID is required']
  },
  answers: [{
    questionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Question',
      required: true
    },
    selectedOptions: [{
      type: Number,
      required: true
    }],
    isCorrect: {
      type: Boolean,
      default: false
    },
    pointsEarned: {
      type: Number,
      default: 0
    }
  }],
  totalScore: {
    type: Number,
    default: 0
  },
  startedAt: {
    type: Date,
    default: Date.now
  },
  submittedAt: {
    type: Date,
    default: null
  },
  status: {
    type: String,
    enum: ['in-progress', 'completed'],
    default: 'in-progress'
  },
  rank: {
    type: Number,
    default: null
  },
  prizeWon: {
    type: String,
    default: null
  }
}, {
  timestamps: true
});

// Index for efficient queries
participationSchema.index({ userId: 1, contestId: 1 }, { unique: true });
participationSchema.index({ contestId: 1, totalScore: -1 });
participationSchema.index({ userId: 1, status: 1 });

module.exports = mongoose.model('Participation', participationSchema);

