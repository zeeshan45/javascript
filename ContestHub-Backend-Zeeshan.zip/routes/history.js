const express = require('express');
const router = express.Router();
const {
  getContestHistory,
  getInProgressContests,
  getPrizes,
  getCompletedContests
} = require('../controllers/historyController');
const { requireAuth } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');

router.get('/contests', requireAuth, apiLimiter, getContestHistory);

router.get('/in-progress', requireAuth, apiLimiter, getInProgressContests);

router.get('/completed', requireAuth, apiLimiter, getCompletedContests);

router.get('/prizes', requireAuth, apiLimiter, getPrizes);

module.exports = router;

