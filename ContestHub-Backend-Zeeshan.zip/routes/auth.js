const express = require('express');
const router = express.Router();
const {
  register,
  login,
  getMe
} = require('../controllers/authController');
const { authenticate, requireAuth } = require('../middleware/auth');
const { validateRegister, validateLogin, validate } = require('../middleware/validator');
const { authLimiter, apiLimiter } = require('../middleware/rateLimiter');

router.post('/register', authLimiter, validateRegister, validate, register);

router.post('/login', authLimiter, validateLogin, validate, login);

router.get('/me', requireAuth, getMe);

module.exports = router;

