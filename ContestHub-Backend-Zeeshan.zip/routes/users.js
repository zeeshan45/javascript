const express = require('express');
const router = express.Router();
const {
  getProfile,
  updateUserRole,
  getUsers
} = require('../controllers/userController');
const { requireAuth, authorize } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');

router.get('/profile', requireAuth, apiLimiter, getProfile);

router.get('/', requireAuth, authorize('admin'), apiLimiter, getUsers);

router.put('/:id/role', requireAuth, authorize('admin'), apiLimiter, updateUserRole);

module.exports = router;

