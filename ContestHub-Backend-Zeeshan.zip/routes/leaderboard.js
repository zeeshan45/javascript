const express = require('express');
const router = express.Router();
const {
  getLeaderboard,
  getUserRank
} = require('../controllers/leaderboardController');
const { authenticate, requireAuth } = require('../middleware/auth');
const { apiLimiter } = require('../middleware/rateLimiter');

router.get('/:contestId', authenticate, apiLimiter, getLeaderboard);

router.get('/:contestId/rank', requireAuth, apiLimiter, getUserRank);

module.exports = router;

