const express = require('express');
const router = express.Router();
const {
  getQuestions,
  getQuestion,
  createQuestion,
  updateQuestion,
  deleteQuestion
} = require('../controllers/questionController');
const { requireAuth, authorize } = require('../middleware/auth');
const { validateQuestion, validate } = require('../middleware/validator');
const { apiLimiter } = require('../middleware/rateLimiter');

router.get('/contest/:contestId', requireAuth, authorize('admin'), apiLimiter, getQuestions);

router.get('/:id', requireAuth, authorize('admin'), apiLimiter, getQuestion);

router.post('/', requireAuth, authorize('admin'), validateQuestion, validate, apiLimiter, createQuestion);

router.put('/:id', requireAuth, authorize('admin'), validateQuestion, validate, apiLimiter, updateQuestion);

router.delete('/:id', requireAuth, authorize('admin'), apiLimiter, deleteQuestion);

module.exports = router;

