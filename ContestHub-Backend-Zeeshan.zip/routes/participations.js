const express = require('express');
const router = express.Router();
const {
  startContest,
  submitAnswers,
  getParticipation
} = require('../controllers/participationController');
const { requireAuth } = require('../middleware/auth');
const { validateAnswers, validate } = require('../middleware/validator');
const { participationLimiter, submissionLimiter } = require('../middleware/rateLimiter');

router.post('/start/:contestId', requireAuth, participationLimiter, startContest);

router.post('/:participationId/submit', requireAuth, submissionLimiter, validateAnswers, validate, submitAnswers);

router.get('/:participationId', requireAuth, getParticipation);

module.exports = router;

