const express = require('express');
const router = express.Router();
const {
  getContests,
  getContest,
  createContest,
  updateContest,
  deleteContest,
  getContestQuestions,
  finalizePrizes
} = require('../controllers/contestController');
const { authenticate, requireAuth, authorize, canAccessContest } = require('../middleware/auth');
const { validateContest, validate } = require('../middleware/validator');
const { apiLimiter, participationLimiter } = require('../middleware/rateLimiter');

router.get('/', authenticate, apiLimiter, getContests);

router.post('/', requireAuth, authorize('admin'), validateContest, validate, apiLimiter, createContest);

router.get('/:id/questions', requireAuth, canAccessContest, participationLimiter, getContestQuestions);

router.post('/:id/finalize-prizes', requireAuth, authorize('admin'), apiLimiter, finalizePrizes);

router.get('/:id', authenticate, canAccessContest, apiLimiter, getContest);

router.put('/:id', requireAuth, authorize('admin'), validateContest, validate, apiLimiter, updateContest);

router.delete('/:id', requireAuth, authorize('admin'), apiLimiter, deleteContest);

module.exports = router;
